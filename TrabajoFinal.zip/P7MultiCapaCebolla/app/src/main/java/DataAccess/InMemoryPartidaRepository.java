package DataAccess;

import java.util.ArrayList;

import Business.Partida;
import Business.IPartidaRepository;

public class InMemoryPartidaRepository implements IPartidaRepository {
    private final ArrayList<Partida> partidas;

    public InMemoryPartidaRepository() {
        this.partidas = new ArrayList<>();
    }

    @Override
    public ArrayList<Partida> getAll() {
        ArrayList<Partida> clone = new ArrayList<>();
        for (Partida partida : partidas) {
            Partida partidaClon = new Partida(
                    partida.jugador1,
                    partida.jugador2,
                    partida.rondasJugadas,
                    partida.nivel,
                    new ArrayList<>(partida.getImagenes()),
                    partida.getCalificacion()
            );
            partidaClon.objectId = partida.objectId;
            clone.add(partidaClon);
        }
        return clone;
    }

    @Override
    public void insert(Partida partida) {
        int counter = this.partidas.size() + 1;
        Partida clonePartida = new Partida(
                partida.jugador1,
                partida.jugador2,
                partida.rondasJugadas,
                partida.nivel,
                new ArrayList<>(partida.getImagenes()),
                partida.getCalificacion()
        );
        clonePartida.objectId = Integer.toString(counter);
        this.partidas.add(clonePartida);

        // Asignar el ID a la partida original
        partida.objectId = clonePartida.objectId;
    }

    @Override
    public Boolean update(Partida partida) {
        for (Partida p : this.partidas) {
            if (p.objectId.equals(partida.objectId)) {
                p.jugador1 = partida.jugador1;
                p.jugador2 = partida.jugador2;
                p.rondasJugadas = partida.rondasJugadas;
                p.nivel = partida.nivel;
                p.setCalificacion(partida.getCalificacion());
                p.setImagenes(new ArrayList<>(partida.getImagenes()));
                return true;
            }
        }
        return false;
    }
}