package DataAccess;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.util.ArrayList;

import Business.Partida;
import Business.IPartidaRepository;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.MediaType;

public class ApiPartidaRepository implements IPartidaRepository {
    private final String API_URL = "https://parseapi.back4app.com/classes/Partida";
    private final String APPLICATION_ID = "a7Zx7UjL3qcLhLDEuZeQr3eziUWLrs7Yw4Gyndd7";
    private final String REST_API_KEY = "6vqyCbcgrAkvb4vxCERHOlGf8WULZg3QEj6adwlw";
    private final OkHttpClient client = new OkHttpClient();
    private final Gson gson = new Gson();

    @Override
    public ArrayList<Partida> getAll() {
        ArrayList<Partida> partidas = new ArrayList<>();
        try {
            Request request = new Request.Builder()
                    .url(API_URL)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .addHeader("Content-Type", "application/json")
                    .get()
                    .build();
            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                String responseJson = response.body().string();
                JsonObject jsonObject = gson.fromJson(responseJson, JsonObject.class);
                JsonArray jsonArray = jsonObject.getAsJsonArray("results");
                for (int i = 0; i < jsonArray.size(); i++) {
                    JsonObject partidaJson = jsonArray.get(i).getAsJsonObject();
                    String jugador1 = partidaJson.get("Jugador1").getAsString();
                    String jugador2 = partidaJson.get("Jugador2").getAsString();
                    String objectId = partidaJson.get("objectId").getAsString();

                    // Obtener los campos con valores por defecto si no existen
                    int rondasJugadas = 1;
                    String nivel = "Medio";
                    int calificacion = 0;
                    ArrayList<String> imagenes = new ArrayList<>();

                    if (partidaJson.has("rondasJugadas")) {
                        rondasJugadas = partidaJson.get("rondasJugadas").getAsInt();
                    }

                    if (partidaJson.has("nivel")) {
                        nivel = partidaJson.get("nivel").getAsString();
                    }

                    if (partidaJson.has("calificacion")) {
                        calificacion = partidaJson.get("calificacion").getAsInt();
                    }

                    if (partidaJson.has("imagenes") && !partidaJson.get("imagenes").isJsonNull()) {
                        JsonArray imagenesJson = partidaJson.getAsJsonArray("imagenes");
                        for (JsonElement imagen : imagenesJson) {
                            imagenes.add(imagen.getAsString());
                        }
                    }

                    Partida partida = new Partida(jugador1, jugador2, rondasJugadas, nivel, imagenes, calificacion);
                    partida.objectId = objectId;
                    partidas.add(partida);
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return partidas;
    }

    @Override
    public void insert(Partida partida) {
        JsonObject partidaJson = new JsonObject();
        partidaJson.addProperty("Jugador1", partida.jugador1);
        partidaJson.addProperty("Jugador2", partida.jugador2);
        partidaJson.addProperty("rondasJugadas", partida.rondasJugadas);
        partidaJson.addProperty("nivel", partida.nivel);
        partidaJson.addProperty("calificacion", partida.calificacion);

        // Agregar el array de imágenes
        JsonArray imagenesJson = new JsonArray();
        for (String imagen : partida.getImagenes()) {
            imagenesJson.add(imagen);
        }
        partidaJson.add("imagenes", imagenesJson);

        String json = gson.toJson(partidaJson);
        try {
            RequestBody body = RequestBody.create(MediaType.get("application/json"), json);
            Request request = new Request.Builder()
                    .url(API_URL)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .post(body)
                    .build();
            Response response = client.newCall(request).execute();
            if (response.body() != null) {
                String responseBody = response.body().string();
                JsonObject responseJson = gson.fromJson(responseBody, JsonObject.class);
                // Asignar el objectId a la partida recibida
                if (responseJson.has("objectId")) {
                    partida.objectId = responseJson.get("objectId").getAsString();
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public Boolean update(Partida partida) {
        boolean isUpdated = false;
        if (partida.objectId == null || partida.objectId.isEmpty()) {
            throw new IllegalArgumentException("La partida debe tener un objectId para poder actualizarla");
        }
        JsonObject partidaJson = new JsonObject();
        partidaJson.addProperty("Jugador1", partida.jugador1);
        partidaJson.addProperty("Jugador2", partida.jugador2);
        partidaJson.addProperty("rondasJugadas", partida.rondasJugadas);
        partidaJson.addProperty("nivel", partida.nivel);
        partidaJson.addProperty("calificacion", partida.calificacion);

        // Agregar el array de imágenes
        JsonArray imagenesJson = new JsonArray();
        for (String imagen : partida.getImagenes()) {
            imagenesJson.add(imagen);
        }
        partidaJson.add("imagenes", imagenesJson);

        String json = gson.toJson(partidaJson);
        try {
            String url = API_URL + "/" + partida.objectId;
            Request request = new Request.Builder()
                    .url(url)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .addHeader("Content-Type", "application/json")
                    .put(RequestBody.create(json, MediaType.get("application/json")))
                    .build();
            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                isUpdated = true;
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return isUpdated;
    }
}