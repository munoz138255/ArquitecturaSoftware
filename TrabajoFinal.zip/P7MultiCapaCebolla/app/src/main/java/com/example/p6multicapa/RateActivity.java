package com.example.p6multicapa;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import Business.Partida;
import Business.PartidaService;

public class RateActivity extends AppCompatActivity {

    private ImageView imgDibujo;
    private ImageView imgFoto;
    private SeekBar seekBarRate;
    private TextView textViewRateValue;
    private PartidaService partidaService;
    private String partidaId;
    private String dibujoPath;
    private String fotoPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate);

        // Inicializar vistas
        imgDibujo = findViewById(R.id.imgDibujo);
        imgFoto = findViewById(R.id.imgFoto);
        seekBarRate = findViewById(R.id.seekBarRate);
        textViewRateValue = findViewById(R.id.textViewRateValue);

        // Obtener el servicio de partidas
        partidaService = ((LayerApplication) getApplicationContext()).getPartidaService();

        // Obtener los datos de la actividad anterior
        Intent intent = getIntent();
        partidaId = intent.getStringExtra("partidaId");
        dibujoPath = intent.getStringExtra("dibujoPath");
        fotoPath = intent.getStringExtra("fotoPath");

        // Cargar las imágenes si existen
        if (dibujoPath != null && !dibujoPath.isEmpty()) {
            Bitmap dibujoBitmap = BitmapFactory.decodeFile(dibujoPath);
            if (dibujoBitmap != null) {
                imgDibujo.setImageBitmap(dibujoBitmap);
            }
        }

        if (fotoPath != null && !fotoPath.isEmpty()) {
            Bitmap fotoBitmap = BitmapFactory.decodeFile(fotoPath);
            if (fotoBitmap != null) {
                imgFoto.setImageBitmap(fotoBitmap);
            }
        }

        // Configurar el seekbar
        seekBarRate.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Actualizar el valor mostrado (progress es 0-9, queremos 1-10)
                int rating = progress + 1;
                textViewRateValue.setText(String.valueOf(rating));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // No necesitamos hacer nada aquí
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // No necesitamos hacer nada aquí
            }
        });
    }

    public void terminarPartida(View view) {
        // Obtener la calificación
        int rating = seekBarRate.getProgress() + 1;

        // Buscar la partida por ID
        Partida partida = null;
        for (Partida p : partidaService.getAll()) {
            if (p.objectId.equals(partidaId)) {
                partida = p;
                break;
            }
        }

        if (partida == null) {
            Toast.makeText(this, "Error: No se encontró la partida", Toast.LENGTH_SHORT).show();
            return;
        }

        // Codificar imágenes en Base64 si existen
        ArrayList<String> imagenes = new ArrayList<>();

        try {
            if (dibujoPath != null && !dibujoPath.isEmpty()) {
                String dibujoBase64 = convertFileToBase64(dibujoPath);
                if (dibujoBase64 != null) {
                    imagenes.add(dibujoBase64);
                }
            }

            if (fotoPath != null && !fotoPath.isEmpty()) {
                String fotoBase64 = convertFileToBase64(fotoPath);
                if (fotoBase64 != null) {
                    imagenes.add(fotoBase64);
                }
            }
        } catch (IOException e) {
            Toast.makeText(this, "Error al procesar las imágenes", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }

        // Actualizar la partida con las imágenes y calificación
        if (partida != null) {
            partida.setImagenes(imagenes);
            partida.setCalificacion(rating);
            boolean updateSuccess = partidaService.update(partida);

            if (updateSuccess) {
                Toast.makeText(this, "Partida terminada y guardada correctamente", Toast.LENGTH_SHORT).show();

                // Volver al menú principal
                Intent mainIntent = new Intent(this, MainActivity.class);
                mainIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Limpiar el stack de actividades
                startActivity(mainIntent);
                finish();
            } else {
                Toast.makeText(this, "Error al guardar la partida", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private String convertFileToBase64(String filePath) throws IOException {
        File file = new File(filePath);
        FileInputStream fileInputStream = new FileInputStream(file);
        byte[] bytes = new byte[(int) file.length()];
        fileInputStream.read(bytes);
        fileInputStream.close();
        return Base64.encodeToString(bytes, Base64.DEFAULT);
    }
}