package com.example.p6multicapa;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import Business.Partida;
import Business.PartidaService;

public class MainActivity extends AppCompatActivity {
    private PartidaService partidaService;
    private ArrayList<Partida> partidasList = new ArrayList<>();
    private ArrayAdapter<Partida> partidasAdapter;
    private static final int REQUEST_ADD = 1;
    private static final int REQUEST_UPDATE = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Usar el servicio global desde LayerApplication
        partidaService = ((LayerApplication) getApplicationContext()).getPartidaService();

        ListView listView = findViewById(R.id.listView);
        partidasAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, partidasList);
        listView.setAdapter(partidasAdapter);

        // Recuperar la lista de partidas usando PartidaService
        partidasList.addAll(partidaService.getAll());
        partidasAdapter.notifyDataSetChanged();

        // Evento en botón para saltar nueva ventana y agregar una nueva partida
        Button btn = findViewById(R.id.btnAddPartida);
        btn.setOnClickListener(this::addItem);

        // Evento al hacer click en un item (Editor)
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Partida selected = partidasList.get(position);

            Intent intent = new Intent(MainActivity.this, EditPartidaActivity.class);
            intent.putExtra("objectId", selected.objectId);
            startActivityForResult(intent, REQUEST_UPDATE); // requestCode 2 para edición
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            // Siempre que vuelva de una activity, se refresca la lista de partidas
            partidasList.clear();
            partidasList.addAll(partidaService.getAll());
            partidasAdapter.notifyDataSetChanged();
        }
    }

    // Iniciar AddPartidaActivity cuando se presione el botón
    public void addItem(View view) {
        Intent intent = new Intent(getApplicationContext(), AddPartidaActivity.class);
        startActivityForResult(intent, REQUEST_ADD);
    }
}