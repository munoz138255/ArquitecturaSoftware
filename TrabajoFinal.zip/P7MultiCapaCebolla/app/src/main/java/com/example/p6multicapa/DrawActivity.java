package com.example.p6multicapa;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import Business.DrawView;

public class DrawActivity extends AppCompatActivity {

    private DrawView drawView;
    private Button btnEnviar;
    private String partidaId;
    private String dibujoPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_draw);

        // Obtener el ID de la partida que viene de la actividad anterior
        Intent intent = getIntent();
        partidaId = intent.getStringExtra("partidaId");

        // Inicializar la vista de dibujo
        drawView = new DrawView(this);
        FrameLayout canvasContainer = findViewById(R.id.canvasContainer);
        canvasContainer.addView(drawView);

        // Configurar el botón de enviar
        btnEnviar = findViewById(R.id.btnEnviarDibujo);
        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Guardar el dibujo como imagen
                saveDibujo();

                // Pasar a la actividad de la cámara
                Intent cameraIntent = new Intent(DrawActivity.this, CameraActivity.class);
                cameraIntent.putExtra("partidaId", partidaId);
                cameraIntent.putExtra("dibujoPath", dibujoPath);
                startActivity(cameraIntent);
                finish(); // Cerrar esta actividad para liberar recursos
            }
        });
    }

    private void saveDibujo() {
        // Crear un bitmap desde la vista de dibujo
        drawView.setDrawingCacheEnabled(true);
        Bitmap bitmap = Bitmap.createBitmap(drawView.getDrawingCache());
        drawView.setDrawingCacheEnabled(false);

        // Crear un archivo para guardar el dibujo
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        File dibujoFile = new File(storageDir, "DIBUJO_" + timeStamp + ".jpg");

        try {
            FileOutputStream out = new FileOutputStream(dibujoFile);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
            out.flush();
            out.close();

            // Guardar la ruta del archivo para pasarla a la siguiente actividad
            dibujoPath = dibujoFile.getAbsolutePath();
            Toast.makeText(this, "Dibujo guardado correctamente", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error al guardar el dibujo", Toast.LENGTH_SHORT).show();
        }
    }
}