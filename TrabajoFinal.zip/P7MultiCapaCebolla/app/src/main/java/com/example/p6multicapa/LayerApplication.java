package com.example.p6multicapa;

import android.app.Application;
import android.os.StrictMode;

import Business.PartidaService;
import Business.IPartidaRepository;
import DataAccess.ApiPartidaRepository;  // Cambiado: importar ApiPartidaRepository en lugar de InMemoryPartidaRepository

public class LayerApplication extends Application {
    private IPartidaRepository partidaRepository;

    @Override
    public void onCreate() {
        super.onCreate();
        // Configuración de políticas de red para permitir operaciones de red en el hilo principal
        // Nota: En una aplicación de producción, deberías usar AsyncTask, Coroutines o RxJava en su lugar
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                .permitAll()
                .build();
        StrictMode.setThreadPolicy(policy);

        // Cambiado: usar ApiPartidaRepository en lugar de InMemoryPartidaRepository
        partidaRepository = new ApiPartidaRepository();
    }

    public PartidaService getPartidaService() {
        return new PartidaService(partidaRepository);
    }
}