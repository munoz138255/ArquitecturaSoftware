package com.example.p6multicapa;

import android.os.Bundle;

import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import Business.Partida;
import Business.PartidaService;

public class EditPartidaActivity extends AppCompatActivity {

    private EditText editTextJugador1;
    private EditText editTextJugador2;
    private EditText editTextObjectId;

    private PartidaService service;
    private String objectId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_partida);

        // Usar el servicio global desde LayerApplication
        service = ((LayerApplication) getApplicationContext()).getPartidaService();

        editTextJugador1 = findViewById(R.id.edit_jugador1);
        editTextJugador2 = findViewById(R.id.edit_jugador2);
        editTextObjectId = findViewById(R.id.edit_objectid);

        // Recibir datos del intent, ahora solo el ID
        Intent intent = getIntent();
        objectId = intent.getStringExtra("objectId");

        // Buscar la partida en base al ID
        for (Partida p : service.getAll()) {
            if (p.objectId.equals(objectId)) {
                editTextObjectId.setText(p.objectId);
                editTextJugador1.setText(p.jugador1);
                editTextJugador2.setText(p.jugador2);
                break;
            }
        }
        editTextObjectId.setEnabled(false); // no editable
    }

    public void saveChanges(View view) {
        String jugador1 = editTextJugador1.getText().toString().trim();
        String jugador2 = editTextJugador2.getText().toString().trim();

        if (jugador1.isEmpty()) jugador1 = "-";
        if (jugador2.isEmpty()) jugador2 = "-";

        Partida updated = new Partida(jugador1, jugador2);
        updated.objectId = objectId;

        boolean success = service.update(updated);

        if (success) {
            setResult(RESULT_OK);
            finish();
        } else {
            Toast.makeText(this, "Error al actualizar la partida", Toast.LENGTH_SHORT).show();
        }
    }
}