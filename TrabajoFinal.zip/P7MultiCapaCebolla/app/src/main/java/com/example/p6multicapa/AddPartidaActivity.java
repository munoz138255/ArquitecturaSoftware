package com.example.p6multicapa;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import Business.Partida;
import Business.PartidaService;

public class AddPartidaActivity extends AppCompatActivity {

    private EditText editTextJ1;
    private EditText editTextJ2;
    private EditText editTextRondas;
    private RadioGroup radioGroupDificultad;
    private PartidaService service;
    private Partida createdPartida = null; // Cambiado: almacenamos la partida completa, no solo el ID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_partida);

        // Usar el servicio global desde LayerApplication
        service = ((LayerApplication) getApplicationContext()).getPartidaService();

        // Inicializar los campos de UI
        editTextJ1 = findViewById(R.id.new_nameJ1);
        editTextJ2 = findViewById(R.id.new_nameJ2);
        editTextRondas = findViewById(R.id.new_rondas);
        radioGroupDificultad = findViewById(R.id.radioGroupDificultad);
    }

    public void add(View view) {
        // Obtener valores de los campos
        String nameJ1 = editTextJ1.getText().toString().trim();
        String nameJ2 = editTextJ2.getText().toString().trim();

        // Establecer valores por defecto si están vacíos
        if (nameJ1.isEmpty()) nameJ1 = "-";
        if (nameJ2.isEmpty()) nameJ2 = "-";

        // Obtener el número de rondas (con valor por defecto si está vacío)
        int rondas = 1;
        try {
            String rondasStr = editTextRondas.getText().toString().trim();
            if (!rondasStr.isEmpty()) {
                rondas = Integer.parseInt(rondasStr);
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Valor de rondas inválido, se usará 1", Toast.LENGTH_SHORT).show();
        }

        // Obtener la dificultad seleccionada
        String nivel = "Fácil"; // Valor por defecto
        int radioButtonId = radioGroupDificultad.getCheckedRadioButtonId();
        if (radioButtonId != -1) {
            RadioButton selectedRadioButton = findViewById(radioButtonId);
            nivel = selectedRadioButton.getText().toString();
        }

        // Crear la nueva partida con todos los datos
        Partida newPartida = new Partida(nameJ1, nameJ2, rondas, nivel);
        boolean success = service.insert(newPartida);

        if (success) {
            // Buscar la partida recién creada por los datos
            for (Partida p : service.getAll()) {
                // Buscar por jugadores, rondas y nivel para encontrar la partida recién creada
                if (p.getJugador1().equals(nameJ1) &&
                        p.getJugador2().equals(nameJ2) &&
                        p.getRondasJugadas() == rondas &&
                        p.getNivel().equals(nivel)) {
                    createdPartida = p;
                    break;
                }
            }

            if (createdPartida != null) {
                Toast.makeText(this, "Partida guardada correctamente", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "La partida se guardó pero no se pudo recuperar su ID", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Mostrar error
            Toast.makeText(this, "Error al crear la partida", Toast.LENGTH_SHORT).show();
        }
    }

    public void comenzarPartida(View view) {
        // Verificar si ya se ha creado una partida
        if (createdPartida == null) {
            // Si no hay partida creada, primero la creamos
            add(view);

            // Si después de intentar crear la partida aún no tenemos la partida, mostramos un error
            if (createdPartida == null) {
                Toast.makeText(this, "Primero debe guardar la partida correctamente", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        // Iniciar la actividad de dibujo
        Intent drawIntent = new Intent(AddPartidaActivity.this, DrawActivity.class);
        drawIntent.putExtra("partidaId", createdPartida.objectId);
        startActivity(drawIntent);
    }
}