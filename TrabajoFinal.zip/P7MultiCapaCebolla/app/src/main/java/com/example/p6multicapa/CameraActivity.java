package com.example.p6multicapa;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.os.Bundle;
import android.os.Environment;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CameraActivity extends AppCompatActivity implements SurfaceHolder.Callback {

    private static final int CAMERA_PERMISSION_REQUEST_CODE = 100;
    private Camera camera;
    private SurfaceView surfaceView;
    private SurfaceHolder surfaceHolder;
    private Button btnCapturar;
    private String partidaId;
    private String dibujoPath;
    private String fotoPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        // Obtener el ID de la partida y el path del dibujo
        Intent intent = getIntent();
        partidaId = intent.getStringExtra("partidaId");
        dibujoPath = intent.getStringExtra("dibujoPath");

        // Inicializar la vista de la cámara
        surfaceView = new SurfaceView(this);
        surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback(this);

        FrameLayout cameraPreview = findViewById(R.id.camera_preview);
        cameraPreview.addView(surfaceView);

        // Configurar el botón de capturar
        btnCapturar = findViewById(R.id.btnCapturar);
        btnCapturar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Capturar la imagen
                if (camera != null) {
                    camera.takePicture(null, null, pictureCallback);
                } else {
                    Toast.makeText(CameraActivity.this, "Error: Cámara no disponible", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Verificar permisos de cámara
        checkCameraPermission();
    }

    private void checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA},
                    CAMERA_PERMISSION_REQUEST_CODE);
        } else {
            openCamera();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            } else {
                Toast.makeText(this, "Se requiere permiso de cámara para esta función", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }

    private void openCamera() {
        try {
            camera = Camera.open();
            setCameraDisplayOrientation();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo acceder a la cámara: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void setCameraDisplayOrientation() {
        if (camera == null) return;

        Camera.CameraInfo info = new Camera.CameraInfo();
        Camera.getCameraInfo(0, info);

        int rotation = getWindowManager().getDefaultDisplay().getRotation();
        int degrees = 0;

        switch (rotation) {
            case Surface.ROTATION_0: degrees = 0; break;
            case Surface.ROTATION_90: degrees = 90; break;
            case Surface.ROTATION_180: degrees = 180; break;
            case Surface.ROTATION_270: degrees = 270; break;
        }

        int result;
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            result = (info.orientation + degrees) % 360;
            result = (360 - result) % 360;  // compensate the mirror
        } else {  // back-facing
            result = (info.orientation - degrees + 360) % 360;
        }

        camera.setDisplayOrientation(result);
    }

    // Callback para guardar la foto capturada
    private Camera.PictureCallback pictureCallback = new Camera.PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            // Guardar la imagen en un archivo
            File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
            File fotoFile = new File(storageDir, "FOTO_" + timeStamp + ".jpg");

            try {
                FileOutputStream fos = new FileOutputStream(fotoFile);
                fos.write(data);
                fos.close();

                // Guardar la ruta del archivo
                fotoPath = fotoFile.getAbsolutePath();

                // Mostrar mensaje de éxito
                Toast.makeText(CameraActivity.this, "Foto capturada con éxito", Toast.LENGTH_SHORT).show();

                // Ir a la actividad de calificación con ambas imágenes
                Intent rateIntent = new Intent(CameraActivity.this, RateActivity.class);
                rateIntent.putExtra("partidaId", partidaId);
                rateIntent.putExtra("dibujoPath", dibujoPath);
                rateIntent.putExtra("fotoPath", fotoPath);
                startActivity(rateIntent);
                finish();

            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(CameraActivity.this, "Error al guardar la foto: " + e.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        }
    };

    @Override
    public void surfaceCreated(@NonNull SurfaceHolder holder) {
        try {
            if (camera != null) {
                camera.setPreviewDisplay(holder);
                camera.startPreview();
            }
        } catch (IOException e) {
            Toast.makeText(this, "Error al iniciar la previsualización: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder holder, int format, int width, int height) {
        // Reiniciar la previsualización si la superficie cambia
        if (surfaceHolder.getSurface() == null) {
            return;
        }

        try {
            camera.stopPreview();
        } catch (Exception e) {
            // Ignorar: intentando detener una previsualización que no existía
        }

        try {
            camera.setPreviewDisplay(surfaceHolder);
            camera.startPreview();
        } catch (Exception e) {
            Toast.makeText(this, "Error al reiniciar la previsualización: " + e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder holder) {
        // Liberar la cámara cuando la superficie se destruye
        if (camera != null) {
            camera.stopPreview();
            camera.release();
            camera = null;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (camera != null) {
            camera.release();
            camera = null;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (camera == null && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            openCamera();
        }
    }
}