package Business;

import java.util.ArrayList;

public class Partida {
    public String objectId;
    public String jugador1;
    public String jugador2;
    public int rondasJugadas;
    public String nivel;
    public ArrayList<String> imagenes;  // Para guardar dibujo y foto
    public int calificacion;           // Para guardar la calificación

    public Partida(String jugador1, String jugador2) {
        this.jugador1 = jugador1;
        this.jugador2 = jugador2;
        this.rondasJugadas = 1;
        this.nivel = "Medio";
        this.imagenes = new ArrayList<>();
        this.calificacion = 0;
    }

    // Constructor completo con todos los campos
    public Partida(String jugador1, String jugador2, int rondasJugadas, String nivel) {
        this.jugador1 = jugador1;
        this.jugador2 = jugador2;
        this.rondasJugadas = rondasJugadas;
        this.nivel = nivel;
        this.imagenes = new ArrayList<>();
        this.calificacion = 0;
    }

    // Constructor completo con todos los campos incluyendo imágenes y calificación
    public Partida(String jugador1, String jugador2, int rondasJugadas, String nivel,
                   ArrayList<String> imagenes, int calificacion) {
        this.jugador1 = jugador1;
        this.jugador2 = jugador2;
        this.rondasJugadas = rondasJugadas;
        this.nivel = nivel;
        this.imagenes = imagenes != null ? imagenes : new ArrayList<>();
        this.calificacion = calificacion;
    }

    // Getter y Setter para jugador1
    public String getJugador1() {
        return jugador1;
    }

    public void setJugador1(String jugador1) {
        this.jugador1 = jugador1;
    }

    // Getter y Setter para jugador2
    public String getJugador2() {
        return jugador2;
    }

    public void setJugador2(String jugador2) {
        this.jugador2 = jugador2;
    }

    // Getter y Setter para rondasJugadas
    public int getRondasJugadas() {
        return rondasJugadas;
    }

    public void setRondasJugadas(int rondasJugadas) {
        this.rondasJugadas = rondasJugadas;
    }

    // Getter y Setter para nivel
    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    // Getter y Setter para imagenes
    public ArrayList<String> getImagenes() {
        return imagenes;
    }

    public void setImagenes(ArrayList<String> imagenes) {
        this.imagenes = imagenes;
    }

    // Getter y Setter para calificacion
    public int getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(int calificacion) {
        this.calificacion = calificacion;
    }

    @Override
    public String toString() {
        String calificacionStr = calificacion > 0 ? String.valueOf(calificacion) : "Pendiente";
        return "Jugador 1: " + jugador1 +
                "\nJugador 2: " + jugador2 +
                "\nRondas: " + rondasJugadas +
                "\nDificultad: " + nivel +
                "\nCalificación: " + calificacionStr +
                "\nID: " + objectId;
    }
}