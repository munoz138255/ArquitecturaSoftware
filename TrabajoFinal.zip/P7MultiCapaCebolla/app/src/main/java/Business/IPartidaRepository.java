package Business;

import java.util.ArrayList;

public interface IPartidaRepository {
    ArrayList<Partida> getAll();
    void insert(Partida partida);
    Boolean update(Partida partida);
}
