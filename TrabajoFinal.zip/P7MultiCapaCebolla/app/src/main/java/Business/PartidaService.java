package Business;

import java.util.ArrayList;

public class PartidaService {
    private IPartidaRepository partidaRepository;

    public PartidaService(IPartidaRepository partidaRepository) {
        this.partidaRepository = partidaRepository;
    }

    public Boolean insert(Partida partida) {
        try {
            partidaRepository.insert(partida);
            // Si la operación completa y la partida tiene objectId, consideramos que fue exitosa
            return partida.objectId != null && !partida.objectId.isEmpty();
        } catch (Exception e) {
            System.out.println("Error al insertar partida: " + e.getMessage());
            return false;
        }
    }

    public Boolean update(Partida partida) {
        return partidaRepository.update(partida);
    }

    public ArrayList<Partida> getAll() {
        return partidaRepository.getAll();
    }
}