package com.example.p6multicapa;

import static org.junit.Assert.*;
import org.junit.Test;

import Business.Employee;
import Business.EmployeeService;

public class EmployeeServiceTests {

    @Test
    public void insert_employee_name_starts_with_uppercase_calls_repo_insert() {
        // Arrange
        Employee employee = new Employee("Roberto", "Monje");
        FakeEmployeeRepository fakeRepo = new FakeEmployeeRepository();
        EmployeeService sut = new EmployeeService(fakeRepo);

        // Act
        Boolean result = sut.insert(employee);

        // Assert
        assertTrue(result);
        assertTrue(fakeRepo.insertInvoked);
    }

    @Test
    public void insert_employee_name_starts_with_lowercase_does_not_call_repo_insert() {
        // Arrange
        Employee employee = new Employee("roberto", "Monje");
        FakeEmployeeRepository fakeRepo = new FakeEmployeeRepository();
        EmployeeService sut = new EmployeeService(fakeRepo);

        // Act
        Boolean result = sut.insert(employee);

        // Assert
        assertFalse(result);
        assertFalse(fakeRepo.insertInvoked);
    }
}

