package com.example.p6multicapa;

import java.util.ArrayList;

import Business.Employee;
import Business.IEmployeeRepository;

public class FakeEmployeeRepository implements IEmployeeRepository {
    public boolean insertInvoked = false;
    public boolean updateInvoked = false;

    @Override
    public ArrayList<Employee> getAll() {
        return new ArrayList<>(); // No se necesita para estos tests
    }

    @Override
    public String insert(Employee employee) {
        insertInvoked = true;
        return "fakeId";
    }

    @Override
    public Boolean update(Employee employee) {
        updateInvoked = true;
        return true;
    }
}

