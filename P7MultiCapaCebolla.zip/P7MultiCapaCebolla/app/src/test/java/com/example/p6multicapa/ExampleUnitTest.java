package com.example.p6multicapa;

import org.junit.Test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import Business.Employee;
import Business.EmployeeService;
import Business.IEmployeeRepository;
import DataAccess.ApiEmployeeRepository;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void getAll_returns_employees() {
        IEmployeeRepository repo = new ApiEmployeeRepository(); // inyección real
        EmployeeService service = new EmployeeService(repo);

        ArrayList<Employee> employees = service.getAll();
        assertFalse(employees.isEmpty());
    }

}