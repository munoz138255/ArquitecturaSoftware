package com.example.p6multicapa;

import static org.junit.Assert.*;

import org.junit.Test;

import java.util.ArrayList;

import Business.Employee;
import DataAccess.ApiEmployeeRepository;

public class DataAccessTest {
    @Test
    public void getAll_returns_employees() {
        ApiEmployeeRepository repo = new ApiEmployeeRepository();
        ArrayList<Employee> employees = repo.getAll();
        assertTrue(!employees.isEmpty());
    }
}
