package com.example.p6multicapa;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import Business.Employee;
import Business.EmployeeService;


public class MainActivity extends AppCompatActivity {
    private EmployeeService employeeService;
    private ArrayList<Employee> employeesList = new ArrayList<>();
    private ArrayAdapter<Employee> employeesAdapter;
    private static final int REQUEST_ADD = 1;
    private static final int REQUEST_UPDATE = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Usar el servicio global desde LayerApplication
        employeeService = ((LayerApplication) getApplicationContext()).getEmployeeService();

        ListView listView = findViewById(R.id.listView);
        employeesAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, employeesList);
        listView.setAdapter(employeesAdapter);

        // Recuperar la lista de empleados usando EmployeeService
        employeesList.addAll(employeeService.getAll());
        employeesAdapter.notifyDataSetChanged();

        // Evento en boton para saltar nueva ventana y agregar un nuevo employee
        Button btn = findViewById(R.id.btnAddEmployee);
        btn.setOnClickListener(this::addItem);

        // Evento al hacer click en un item (Editor)
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Employee selected = employeesList.get(position);

            Intent intent = new Intent(MainActivity.this, EditEmployeeActivity.class);
            intent.putExtra("objectId", selected.objectId);
            startActivityForResult(intent, REQUEST_UPDATE); // requestCode 2 para edición
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            // Siempre que vuelva de una activity, se refresca la lista de empleados
            employeesList.clear();
            employeesList.addAll(employeeService.getAll());
            employeesAdapter.notifyDataSetChanged();
        }
    }

    // Iniciar AddEmployeeActivity cuando se presione el boton
    public void addItem(View view) {
        Intent intent = new Intent(getApplicationContext(), AddEmployeeActivity.class);
        startActivityForResult(intent, REQUEST_ADD);
    }
}