package com.example.p6multicapa;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import Business.Employee;
import Business.EmployeeService;

public class AddEmployeeActivity extends AppCompatActivity {

    private EditText editTextName;
    private EditText editTextSurname;

    private EmployeeService service;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_employee);

        // Usar el servicio global desde LayerApplication
        service = ((LayerApplication)getApplicationContext()).getEmployeeService();

        editTextName = findViewById(R.id.new_name);
        editTextSurname = findViewById(R.id.new_surname);
    }

    public void add(View view) {
        String name = editTextName.getText().toString().trim();
        String surname = editTextSurname.getText().toString().trim();

        if (name.isEmpty()) name = "-";
        if (surname.isEmpty()) surname = "-";

        Employee newEmployee = new Employee(name, surname);
        boolean success = service.insert(newEmployee);

        if (success) {
            Intent resultIntent = new Intent();
            resultIntent.putExtra("objectId", newEmployee.objectId); // puede que esto sea null si no se setea dentro del repositorio
            setResult(RESULT_OK, resultIntent);
            finish();
        } else {
            // Mostrar error (puedes usar Toast o un diálogo)
            Toast.makeText(this, "El nombre debe empezar por mayúscula", Toast.LENGTH_SHORT).show();
        }
    }
}