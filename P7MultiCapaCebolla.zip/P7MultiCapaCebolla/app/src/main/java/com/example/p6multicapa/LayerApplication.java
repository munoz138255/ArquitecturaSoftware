package com.example.p6multicapa;

import android.app.Application;
import android.os.StrictMode;

import Business.EmployeeService;
import Business.IEmployeeRepository;
import DataAccess.ApiEmployeeRepository;
import DataAccess.InMemoryEmployeeRepository;

public class LayerApplication extends Application {
    private IEmployeeRepository employeeRepository;
    @Override
    public void onCreate() {
        super.onCreate();
        StrictMode.ThreadPolicy gfgPolicy = new StrictMode.ThreadPolicy.Builder()
                .permitAll()
                .build();
        StrictMode.setThreadPolicy(gfgPolicy);

        // Permitir llamadas síncronas
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                .permitAll()
                .build();
        StrictMode.setThreadPolicy(policy);

        // Cambia el repositorio según lo que quieras probar
        employeeRepository = new InMemoryEmployeeRepository(); // si estás probando sin conexión
        //employeeRepository = new ApiEmployeeRepository();


    }
    public EmployeeService getEmployeeService(){
        return new EmployeeService(employeeRepository);
    }
}
