package com.example.p6multicapa;

import android.os.Bundle;

import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import Business.Employee;
import Business.EmployeeService;

public class EditEmployeeActivity extends AppCompatActivity {

    private EditText editTextName;
    private EditText editTextSurname;
    private EditText editTextObjectId;

    private EmployeeService service;
    private String objectId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_employee);

        // Usar el servicio global desde LayerApplication
        service = ((LayerApplication)getApplicationContext()).getEmployeeService();

        editTextName = findViewById(R.id.edit_name);
        editTextSurname = findViewById(R.id.edit_surname);
        editTextObjectId = findViewById(R.id.edit_objectid);

        // Recibir datos del intent, ahora solo el ID
        Intent intent = getIntent();
        objectId = intent.getStringExtra("objectId");

        // Buscar al empleado en base al ID
        for (Employee e : service.getAll()) {
            if (e.objectId.equals(objectId)) {
                editTextObjectId.setText(e.objectId);
                editTextName.setText(e.Name);
                editTextSurname.setText(e.Surname);
                break;
            }
        }
        editTextObjectId.setEnabled(false); // no editable
    }

    public void saveChanges(View view) {
        String name = editTextName.getText().toString().trim();
        String surname = editTextSurname.getText().toString().trim();

        if (name.isEmpty()) name = "-";
        if (surname.isEmpty()) surname = "-";

        Employee updated = new Employee(name, surname);
        updated.objectId = objectId;

        boolean success = service.update(updated);

        if (success) {
            setResult(RESULT_OK);
            finish();
        } else {
            Toast.makeText(this, "El nombre debe empezar por mayúscula", Toast.LENGTH_SHORT).show();
        }
    }
}