package DataAccess;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;

import Business.Employee;
import Business.IEmployeeRepository;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.MediaType;

public class ApiEmployeeRepository implements IEmployeeRepository {
    private final String API_URL = "https://parseapi.back4app.com/classes/Employee";
    private final String APPLICATION_ID = "mPK9EtBGiOLcRY9tCwfglNhunR8eT4tJ5hkb8im9"; // ToDo. Pon aqui tú ID
    private final String REST_API_KEY = "Kck6qo6wEifXxL0UFpHszIf5Q7u7kNuyxL9MK9sa"; // ToDo. Pon aqui tú clave
    private final OkHttpClient client = new OkHttpClient();
    private final Gson gson = new Gson();


    public ArrayList<Employee> getAll() {
        ArrayList<Employee> employees = new ArrayList<Employee>();
        try {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(API_URL)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .addHeader("Content-Type", "application/json")
                    .get()
                    .build();
            Response response = client.newCall(request).execute();
            if (response.code() == 200) {
                String responseJson = response.body().string();
                System.out.println(responseJson);
                JsonObject jsonObject = new Gson().fromJson(responseJson, JsonObject.class);
                JsonArray jsonArray = jsonObject.getAsJsonArray("results");
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<Employee>>() {
                }.getType();
                employees = gson.fromJson(jsonArray, listType);
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return employees;
    }

    public String insert(Employee employee) {
        String objectId = "";
        String json = gson.toJson(employee);
        try {
            RequestBody body = RequestBody.create(MediaType.get("application/json"), json);
            Request request = new Request.Builder()
                    .url(API_URL)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .post(body)
                    .build();
            Response response = client.newCall(request).execute();
            if (!response.isSuccessful()) {
                System.out.println("Error en la API: " + response.code() + " " + response.message());
                return "ERROR";
            }
            if (response.body() != null) {
                String responseBody = response.body().string();
                System.out.println("Respuesta de la API: " + responseBody); // Para depurar

                Employee newEmployee = gson.fromJson(responseBody, Employee.class);
                objectId = newEmployee.objectId;
            }
        } catch (IOException e) {
            System.out.println("IOException: " + e.getMessage());
        }
        return objectId;
    }

    public Boolean update(Employee employee) {
        boolean isUpdated = false;
        Gson gson = new Gson();
        // Asegurarse de que el empleado tiene un objectId
        if (employee.objectId == null || employee.objectId.isEmpty()) {
            throw new IllegalArgumentException("El empleado debe tener un objectId para poder actualizarlo");
        }
        // Convertir el empleado a JSON
        String json = gson.toJson(employee);
        try {
            // URL con el objectId para actualizar el empleado
            String url = API_URL + "/" + employee.objectId; // Usa el objectId del empleado para hacer la petición PUT
            // Hacer la solicitud PUT
            Request request = new Request.Builder()
                    .url(url)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .addHeader("Content-Type", "application/json")
                    .put(RequestBody.create(json, MediaType.get("application/json")))
                    .build();
            OkHttpClient client = new OkHttpClient();
            Response response = client.newCall(request).execute();
            // Si la respuesta es exitosa, devolver true
            if (response.isSuccessful()) {
                isUpdated = true;
            }
        } catch (IOException | IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
        return isUpdated;
    }
}