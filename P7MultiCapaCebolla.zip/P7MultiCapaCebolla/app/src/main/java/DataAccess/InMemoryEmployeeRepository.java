package DataAccess;

import java.util.ArrayList;

import Business.Employee;
import Business.IEmployeeRepository;

public class InMemoryEmployeeRepository implements IEmployeeRepository {
    private final ArrayList<Employee> employees;
    public InMemoryEmployeeRepository() {
        this.employees = new ArrayList<Employee>();
    }
    @Override
    public ArrayList<Employee> getAll() {
        // Cuidado! NO debemos devolver la referencia al objeto interno employees
        // Debemos devolver el contenido del objeto employees,
        // no el propio objeto employees.
        // Para proteger la lista de empleados de modificaciones externas
        // debemos devolver una nueva lista, no los objetos internos.
        ArrayList<Employee> clone = new ArrayList<Employee>();
        for(Employee employee : employees){
            Employee employeeClon = new Employee(employee.Name, employee.Surname);
            employeeClon.objectId = employee.objectId;
            clone.add(employeeClon);
        }
        return clone;
    }
    @Override
    public String insert(Employee employee) {
        int counter = this.employees.size() + 1;
        Employee cloneEmployee = new Employee(employee.Name, employee.Surname);
        cloneEmployee.objectId = Integer.toString(counter);
        this.employees.add(cloneEmployee);
        return cloneEmployee.objectId;
    }
    @Override
    public Boolean update(Employee employee) {
        for(Employee em : this.employees) {
            if (em.objectId.equals(employee.objectId)) {
                em.Name = employee.Name;
                em.Surname = employee.Surname;
                return true;
            }
        }
        return false;
    }
}