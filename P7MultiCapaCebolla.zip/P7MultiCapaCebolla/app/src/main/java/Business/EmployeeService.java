package Business;

import java.util.ArrayList;

public class EmployeeService {
    private IEmployeeRepository employeeRepository;

    public EmployeeService(IEmployeeRepository employeeRepository){
        this.employeeRepository = employeeRepository;
    }

    public Boolean insert(Employee employee) {
        if (employee.isUpperFirstChar()) return false;
        employeeRepository.insert(employee);
        return true;
    }

    public Boolean update(Employee employee) {
        if (employee.isUpperFirstChar()) return false;
        return employeeRepository.update(employee);
    }

    public ArrayList<Employee> getAll() {
        return employeeRepository.getAll();
    }
}
