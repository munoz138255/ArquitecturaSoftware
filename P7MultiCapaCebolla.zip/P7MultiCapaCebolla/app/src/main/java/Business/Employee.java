package Business;

public class Employee {
    public String objectId;
    public String Name;
    public String Surname;
    public Employee(String name, String surname){
        Name = name;
        Surname = surname;
    }

    // Getter y Setter para el nombre
    public String getNombre() {
        return Name;
    }

    public void setNombre(String Name) {
        this.Name = Name;
    }

    // Getter y Setter para el apellido
    public String getApellido() {
        return Surname;
    }

    public void setApellido(String surname) {
        this.Surname = surname;
    }

    public boolean isUpperFirstChar() {
        if (Name == null || Name.isEmpty()) return true;
        return !Character.isUpperCase(Name.charAt(0));
    }

    @Override
    public String toString() {
        return "Nombre: " + Name + "\nApellido: " + Surname + "\nID: " + objectId;
    }
}
