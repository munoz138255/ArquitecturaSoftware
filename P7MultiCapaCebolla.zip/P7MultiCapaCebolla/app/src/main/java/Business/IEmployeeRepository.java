package Business;

import java.util.ArrayList;

public interface IEmployeeRepository {
    ArrayList<Employee> getAll();
    String insert(Employee employee);
    Boolean update(Employee employee);
}
