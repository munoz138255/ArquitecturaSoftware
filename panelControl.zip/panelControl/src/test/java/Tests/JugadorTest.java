package Tests;

import modelo.Jugador;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class JugadorTest {

    @Test
    public void testGettersAndSetters() {
        Jugador jugador = new Jugador("Pedro");
        assertEquals("Pedro", jugador.getNombre());

        jugador.setNombre("Pedro Actualizado");
        assertEquals("Pedro Actualizado", jugador.getNombre());

        jugador.setPuntuacion(100);
        assertEquals(100, jugador.getPuntuacion());
    }

    @Test
    public void testToString() {
        Jugador jugador = new Jugador("Maria");
        jugador.setPuntuacion(50);
        assertEquals("Maria (Puntuación: 50.0)", jugador.toString());
    }
}
