package Tests;

import DAO.RegistroPartidas;
import modelo.Jugador;
import modelo.Partida;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class RegistroPartidasTest {

    private RegistroPartidas registroPartidas;

    @BeforeEach
    public void setUp() {
        registroPartidas = new RegistroPartidas();
    }

    @Test
    public void testCrearPartida() {
        List<Jugador> jugadores = new ArrayList<>();
        jugadores.add(new Jugador("Jugador 1"));
        jugadores.add(new Jugador("Jugador 2"));

        Partida partida = new Partida(1, jugadores);
        registroPartidas.crearPartida(partida);

        List<Partida> partidas = registroPartidas.listarPartidas();
        assertEquals(1, partidas.size());
        assertEquals(1, partidas.get(0).getId());
    }

    @Test
    public void testObtenerPartidaPorID() {
        List<Jugador> jugadores = new ArrayList<>();
        jugadores.add(new Jugador("Jugador 1"));
        jugadores.add(new Jugador("Jugador 2"));

        Partida partida = new Partida(1, jugadores);
        registroPartidas.crearPartida(partida);

        Partida encontrada = registroPartidas.obtenerPartidaPorID(1);
        assertNotNull(encontrada);
        assertEquals(1, encontrada.getId());
    }

    @Test
    public void testActualizarPartida() {
        List<Jugador> jugadores = new ArrayList<>();
        jugadores.add(new Jugador("Jugador 1"));
        jugadores.add(new Jugador("Jugador 2"));

        Partida partida = new Partida(1, jugadores);
        registroPartidas.crearPartida(partida);

        jugadores.add(new Jugador("Jugador 3"));
        partida.setJugadores(jugadores);
        registroPartidas.actualizarPartida(partida);

        Partida actualizada = registroPartidas.obtenerPartidaPorID(1);
        assertEquals(3, actualizada.getJugadores().size());
    }

    @Test
    public void testEliminarPartida() {
        List<Jugador> jugadores = new ArrayList<>();
        jugadores.add(new Jugador("Jugador 1"));
        jugadores.add(new Jugador("Jugador 2"));

        Partida partida = new Partida(1, jugadores);
        registroPartidas.crearPartida(partida);

        registroPartidas.eliminarPartida(partida);

        Partida eliminada = registroPartidas.obtenerPartidaPorID(1);
        assertNull(eliminada);
    }
}
