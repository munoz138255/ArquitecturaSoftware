package Tests;

import DAO.RegistroJugadores;
import modelo.Jugador;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class RegistroJugadoresTest {

    private RegistroJugadores registroJugadores;

    @BeforeEach
    public void setUp() {
        registroJugadores = new RegistroJugadores();
    }

    @Test
    public void testCrearJugador() {
        Jugador jugador = new Jugador("Juan");
        registroJugadores.crearJugador(jugador);

        List<Jugador> jugadores = registroJugadores.listarJugadores();
        assertEquals(1, jugadores.size());
        assertEquals("Juan", jugadores.get(0).getNombre());
    }

    @Test
    public void testObtenerJugador() {
        Jugador jugador = new Jugador("Ana");
        registroJugadores.crearJugador(jugador);

        Jugador encontrado = registroJugadores.obtenerJugador("Ana");
        assertNotNull(encontrado);
        assertEquals("Ana", encontrado.getNombre());
    }

    @Test
    public void testActualizarJugador() {
        Jugador jugador = new Jugador("Carlos");
        registroJugadores.crearJugador(jugador);

        jugador.setNombre("Carlos Actualizado");
        registroJugadores.actualizarJugador(jugador);

        Jugador actualizado = registroJugadores.obtenerJugador("Carlos Actualizado");
        assertNotNull(actualizado);
        assertEquals("Carlos Actualizado", actualizado.getNombre());
    }

    @Test
    public void testEliminarJugador() {
        Jugador jugador = new Jugador("Luis");
        registroJugadores.crearJugador(jugador);

        registroJugadores.eliminarJugador(jugador);

        Jugador eliminado = registroJugadores.obtenerJugador("Luis");
        assertNull(eliminado);
    }
}
