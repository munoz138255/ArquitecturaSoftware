package com.example.aplicacionbase;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    // Metodos para manejar los clics de los botones
    public void addPlayer(View view) {
        Snackbar.make(view, "Jugador creado", Snackbar.LENGTH_SHORT).show();
    }

    public void removePlayer(View view) {
        Snackbar.make(view, "Jugador eliminado", Snackbar.LENGTH_SHORT).show();
    }

    public void addGame(View view) {
        Snackbar.make(view, "Partida creada", Snackbar.LENGTH_SHORT).show();
    }

    public void removeGame(View view) {
        Snackbar.make(view, "Partida eliminada", Snackbar.LENGTH_SHORT).show();
    }
}